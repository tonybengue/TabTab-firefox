function onCreated(tab) {
  console.log(`Created new tab: ${tab.id}`)
}

function onError(error) {
  console.log(`Error: ${error}`)
}

function newTab(url) {
  browser.browserAction.onClicked.addListener(() => {
    let creating = browser.tabs.create({
      url: url
    })
    creating.then(onCreated, onError)
  })
}

document.body.style.border = '5px solid red'