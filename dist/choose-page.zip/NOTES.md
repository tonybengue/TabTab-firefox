https://duckduckgo.com/?q=chien&ia=web
https://www.qwant.com/?q=chien&t=web
https://yandex.com/search/?text=chat&lr=105067
https://www.bing.com/search?q=chat

How to Publish your Chrome Extension 1/4 - Getting Started - YouTube https://www.youtube.com/watch?v=UWSxfcWHejY
How to Sell a Google Chrome Extension and Make $4,012 in Just 7 Days https://extensionworkshop.com/documentation/publish/make-money-from-browser-extensions/
Make money firefox https://extensionworkshop.com/documentation/publish/make-money-from-browser-extensions/
How do Chrome add-ons make money? https://www.quora.com/How-do-Chrome-add-ons-make-money
https://earnpace.com/make-money-chrome-extension/

- [ ] Freemium ou modele payant

- Notifications si site publie de nouvelles annonces
  lbc

## LBC
https://www.leboncoin.fr/deposer-une-annonce
Titre
Location / Ventes / Colloc
Offre / demande
Maison / Appartement / Terrain / Parking / Autre
Maison
  surface habitable
  surface totale du terrain
  nombre de pieces
  nombre de niveaux
  exterieur
    balcon
    terrasse
    jardin
  place parking
    0,1,2,3,4,5,6 et +
  classe énergie
    A,B,C,D,E,F,G,Vierge
  GES
    A,B,C,D,E,F,G,Vierge
  Titre
  description (> 15 & < 4000)
  Prix de vente
  Photos (3 max en gratuit)
  Localisation
  Tel?
  Masquer num?
  Refuser demarchage?
Appartement
  surface habitable
  nombre de pieces
  Etage du bien
  Etages de l'immeuble
  Exterieur
    balcon
    terrasse
    jardin
  place parking
    0,1,2,3,4,5,6 et +
  classe énergie
    A,B,C,D,E,F,G,Vierge
  GES
    A,B,C,D,E,F,G,Vierge
  Titre
  description (> 15 & < 4000)
  Prix de vente
  Photos (3 max en gratuit)
  Localisation
  Tel?
  Masquer num?
  Refuser demarchage?
  Continuer
  Déposer sans booster

Chrome extension ideas: twitter / Reddit