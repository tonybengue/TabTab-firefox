# Tabtab browser extension
This project is about a browser extension which modify the new tab page by retweeking it.
Later I'll maybe add geolocalisation, weather, bookmarks ...

It is available on:
- [Firefox](https://addons.mozilla.org/fr/firefox/addon/tabtab/)

# Ideas
- [ ] Add new search engines
